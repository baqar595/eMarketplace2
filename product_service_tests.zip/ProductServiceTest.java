package com.emarketplace.service;

import com.emarketplace.model.Product;
import com.emarketplace.repository.ProductRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ProductServiceTest {

    @Mock
    private ProductRepository productRepository;

    @InjectMocks
    private ProductService productService;

    @Test
    void testGetProductByIdReturnsProduct() {
        Product mockProduct = new Product(1L, "Test Product", 100.0);
        when(productRepository.findById(1L)).thenReturn(Optional.of(mockProduct));

        Product result = productService.getProductById(1L);

        assertNotNull(result);
        assertEquals("Test Product", result.getName());
        assertEquals(100.0, result.getPrice());
        verify(productRepository).findById(1L);
    }

    @Test
    void testGetProductByIdThrowsException() {
        when(productRepository.findById(2L)).thenThrow(new RuntimeException("Database error"));

        assertThrows(RuntimeException.class, () -> productService.getProductById(2L));
        verify(productRepository).findById(2L);
    }
}